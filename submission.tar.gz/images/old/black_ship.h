/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x30 black_ship black_ship.png 
 * Time-stamp: Thursday 04/08/2021, 17:05:47
 * 
 * Image Information
 * -----------------
 * black_ship.png 30@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLACK_SHIP_H
#define BLACK_SHIP_H

extern const unsigned short black_ship[900];
#define BLACK_SHIP_SIZE 1800
#define BLACK_SHIP_LENGTH 900
#define BLACK_SHIP_WIDTH 30
#define BLACK_SHIP_HEIGHT 30

#endif

