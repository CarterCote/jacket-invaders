/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x30 black_alien black_alien.png 
 * Time-stamp: Thursday 04/08/2021, 17:09:17
 * 
 * Image Information
 * -----------------
 * black_alien.png 30@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLACK_ALIEN_H
#define BLACK_ALIEN_H

extern const unsigned short black_alien[900];
#define BLACK_ALIEN_SIZE 1800
#define BLACK_ALIEN_LENGTH 900
#define BLACK_ALIEN_WIDTH 30
#define BLACK_ALIEN_HEIGHT 30

#endif

