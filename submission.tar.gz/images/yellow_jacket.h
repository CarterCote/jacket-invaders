/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x30 yellow_jacket yellow_jacket.png 
 * Time-stamp: Friday 11/12/2021, 23:04:35
 * 
 * Image Information
 * -----------------
 * yellow_jacket.png 30@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef YELLOW_JACKET_H
#define YELLOW_JACKET_H

extern const unsigned short yellow_jacket[900];
#define YELLOW_JACKET_SIZE 1800
#define YELLOW_JACKET_LENGTH 900
#define YELLOW_JACKET_WIDTH 30
#define YELLOW_JACKET_HEIGHT 30

#endif

