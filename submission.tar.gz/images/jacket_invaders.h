/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 jacket_invaders jacket_invaders.png 
 * Time-stamp: Friday 11/12/2021, 23:18:45
 * 
 * Image Information
 * -----------------
 * jacket_invaders.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef JACKET_INVADERS_H
#define JACKET_INVADERS_H

extern const unsigned short jacket_invaders[38400];
#define JACKET_INVADERS_SIZE 76800
#define JACKET_INVADERS_LENGTH 38400
#define JACKET_INVADERS_WIDTH 240
#define JACKET_INVADERS_HEIGHT 160

#endif

